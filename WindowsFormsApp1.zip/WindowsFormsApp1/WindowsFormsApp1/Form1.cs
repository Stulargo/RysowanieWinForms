﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            Pen pioro = new Pen(Color.Black, 2);

            Pen pioro2 = new Pen(Color.White, 2);

            Brush tlo = new SolidBrush(Color.Black);

            /*int x1 = 0;
            int y1 = 0;
            int x2 = 100;
            int y2=100;
            
            g.DrawEllipse(pioro,x1,y1,x2,y2);

            g.FillEllipse(tlo, x1, y1, x2, y2); 

            //g.DrawRectangle(pioro,x1,y1,x2,y2);

            int x1 = 0;
            int y1 = 0;
            int x2 = 100;
            int y2 = 100;
            g.DrawRectangle(pioro, x1, y1, x2, y2);

            //g.FillRectangle(tlo, x1, y1, x2, y2);

            g.DrawLine(pioro,0,0,100,100);
            g.DrawLine(pioro, 100, 0, 0, 100); */

            //Zadanie rysowanie linii jako przekatna w kwadracie ale zeby bylo widac jak ona sie rysuje
            /*
            for (int i = 0; i <=100; i++){
                g.DrawLine(pioro,0,0,i,i);
                g.DrawLine(pioro,100,0,100-i,i);
                Thread.Sleep(30);
            }
            */

            //Kuleczka ktora sie przesuwa i nie pozostawia śladu


            for (int i = 0; i < 100; i++)
            {
                g.DrawLine(pioro, 0, 0, i, i);
                g.DrawLine(pioro, 100, 0, 100 - i, i);

                Thread.Sleep(30);
                g.DrawEllipse(pioro2, 200 + i - 1, 200, 20, 20);
                g.DrawEllipse(pioro, 200 + i, 200, 20, 20);
                g.FillEllipse(tlo, 200 + i, 200, 20, 20);
            
            }


        }
    }
}
