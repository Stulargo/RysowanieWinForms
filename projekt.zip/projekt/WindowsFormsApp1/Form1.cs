﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

/*po nacisnieciu na quiz (podmenu sprawdz nazwisko a drugie podmenu to rozwiąż quiz) pojawia się label podaj nazwisko, przycisk sprawdź po kliknięciu plik tekstowy w którym będą nazwiska i ilość punktów zdobytych za quiz np. Nazwisko kowalski to trzeba sprawdzić czy w pliku znajduje się nazwisko kowalski jeżeli się znajdzie niech wyskoczy okienko z komunikatem np. Kowalski twój ostatni wynik z testu to 3 punkty, ale jak nie znajdzie nazwiska w pliku to wyjdzie komunikat np. Kowalski rozwiązujesz test po raz pierwszy


2 zakladka rozwiąż quiz 5 pytań matematycznych różnego typu odpowiedzi (radio butony, lista jednokrotnego i wielokrotnego, checkboxy itp.) przycisk sprawdz odpowiedzi to wtedy messagebox "wynik quizu X punkty/punktów" 
jeżeli było już nazwisko to powinnismy albo zmienić liczbe punktów albo dopisać nowe nazwisko z nowa iloscia punktów i usunąć starszy rekord tylko wtedy jak liczba punktów była mniejsza niż nowy uzyskany wynik (funkcja split(" "))*/
//file.ReadAllText / ReadLineText





namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {


        void UkryKolory() 
        {
            label8.Visible = false;
            label7.Visible = false;
            label6.Visible = false;
            hScrollBar1.Visible = false;
            hScrollBar2.Visible = false;
            hScrollBar3.Visible = false;
            button4.Visible = false;
            textBox8.Visible = false;
            textBox7.Visible = false;
            textBox6.Visible = false;
            textBox5.Visible = false;
            panel1.Visible = false;

        }

        void PokazKolory() 
        {
            label8.Visible = true;
            label7.Visible = true;
            label6.Visible = true;
            hScrollBar1.Visible = true;
            hScrollBar2.Visible = true;
            hScrollBar3.Visible = true;
            button4.Visible = true;
            textBox8.Visible = true;
            textBox7.Visible = true;
            textBox6.Visible = true;
            textBox5.Visible = true;
            panel1.Visible = true;
        }
        void UkryjQuiz() 
        {
            groupBox1.Visible = false;
            label4.Visible = false;
        }
        void PokazQuiz()
        {
            groupBox1.Visible = true;
            label4.Visible = true;
        }
        public Form1()
        {
            InitializeComponent();
            textBox1.Visible = false;

            textBox2.Visible = false;

            textBox3.Visible = false;
            button1.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            textBox4.Visible = false;
            button2.Visible = false;
            groupBox1.Visible = false;
            panel2.Visible = false;
            UkryKolory();
            UkryjQuiz();
        }
        private float wynik = 0;
        private int id;

        private void kołoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
            button1.Visible = true;
            label2.Visible = false;
            label3.Visible = false;
            textBox2.Visible = false;

            label1.Text = "Podaj promień koła:";
            textBox1.Text = "";
            id = 1;
            UkryKolory();
            UkryjQuiz();
        }
        private void prostokątToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
            label2.Visible=true;
            textBox2.Visible=true;
            button1.Visible = true;
            label1.Text = "Podaj pierwszy bok prostokąta:";
            label2.Text = "Podaj drugi bok prostokąta:";
            id = 2;
            UkryKolory();
            UkryjQuiz();
        }

        private void kwadratToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Visible=true;
            textBox1.Visible=true;
            button1.Visible=true;
            label1.Text = "Podaj długość boku kwadratu";
            id = 3;
            label2.Visible = false;
            label3.Visible = false;
            textBox2.Visible = false;
            UkryKolory();
            UkryjQuiz();
        }
        private void kołoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible=true;
            label2.Visible=false;
            textBox2.Visible = false;
            button1.Visible=true;
            textBox3.Visible=true;
            label3.Visible = true;
            label1.Text = "Podaj promień koła:";
            textBox1.Text = "";
            label3.Text = "";
            id = 4;
            UkryKolory();
            UkryjQuiz();
        }

        private void walecToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //objetosc
            id = 5;
            label1.Visible=true;
            textBox1.Visible=true;
            label2.Visible=true;
            textBox2.Visible=true;
            textBox1.Text = "";
            textBox2.Text = "";
            label1.Text = "Podaj promień podstawy walca";
            label2.Text = "Podaj wysokość walca";
            label3.Text = "";
            button1.Visible = true;
            textBox3.Visible = true;
            label3.Visible = true;
            UkryKolory();
            UkryjQuiz();
        }

        private void stożekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //objetosc
            id = 6;
            label1.Visible = true;
            textBox1.Visible = true;
            label2.Visible = true;
            textBox2.Visible = true;
            textBox1.Text = "";
            textBox2.Text = "";
            label1.Text = "Podaj promień podstawy stożka";
            label2.Text = "Podaj wysokość stożka";
            label3.Text = "";
            button1.Visible = true;
            textBox3.Visible = true;
            label3.Visible = true;
            UkryKolory();
            UkryjQuiz();
        }

        private void kulaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //pole powierzchni
            label1.Visible = true;
            textBox1.Visible = true;
            button1.Visible = true;
            label2.Visible = false;
            label3.Visible = false;
            textBox2.Visible = false;

            label1.Text = "Podaj promień kuli:";
            textBox1.Text = "";
            id = 7;
            UkryKolory();
            UkryjQuiz();

        }

        private void sprawdźNazwiskoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            id = 8;
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            button1.Visible = false;
            label1.Visible = false;
            label3.Visible = false;
            label2.Visible = true;
            label1.Visible = false;
            label3.Visible = false;
            textBox2.Visible = true;
            textBox1.Visible = false;
            textBox3.Visible = false;
            label2.Text = "Podaj nazwisko";
            button1.Visible = false;
            button2.Visible = true;
            button2.Text = "Sprawdź";
            UkryKolory();
            UkryjQuiz();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            switch (id) {

                case 1:
                    textBox3.Visible = true;
                    label3.Visible=true;
                    float promien = float.Parse(textBox1.Text);
                    wynik = (float)(Math.PI * promien * promien);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Pole koła o promieniu " + promien + " wynosi: ";
                    break;
                case 2:
                    textBox3.Visible = true;
                    label3.Visible = true;
                    float bok1 = float.Parse(textBox1.Text);
                    float bok2 = float.Parse(textBox2.Text);
                    wynik = bok1 * bok2;
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Pole prostokąta o bokach: " + bok1 + " oraz " + bok2 + " wynosi: ";
                    break;
                case 3:
                    textBox3.Visible = true;
                    label3.Visible = true;
                    label3.Visible= true;
                    float bok = float.Parse(textBox1.Text);
                    wynik = bok * 4;
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Obwod kwadratu o boku " + bok + " wynosi: ";
                    break;
                case 4:
                    promien = float.Parse(textBox1.Text);
                    wynik = (float)(2 * Math.PI * promien);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Obwod kola o promieniu " + promien + " wynosi: ";
                    break;
                case 5:
                    promien = float.Parse(textBox1.Text);
                    float wysokosc = float.Parse(textBox2.Text);
                    wynik = (float)(Math.PI * Math.Pow(promien,2)* wysokosc);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Objętość walca o promieniu podstawy " + promien + " i o wysokości "+wysokosc+" wynosi: ";
                    break;
                case 6:
                    promien = float.Parse(textBox1.Text);
                    wysokosc = float.Parse(textBox2.Text);
                    wynik = (float)((Math.PI * Math.Pow(promien, 2) * wysokosc));
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Objętość walca o promieniu podstawy " + promien + " i o wysokości " + wysokosc + " wynosi: ";
                    break;
                case 7:
                    textBox3.Visible = true;
                    label3.Visible = true;
                    promien = float.Parse(textBox1.Text);
                    wynik = (float)(4 * Math.PI * promien * promien);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Pole powierzchni kuli o promieniu " + promien + " wynosi: ";
                    break;
            }
            UkryKolory();
            UkryjQuiz();
        }



        private void rozwiążQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;

            textBox2.Visible = false;

            textBox3.Visible = false;
            button1.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = true;
            label5.Visible = true;
            textBox4.Visible = true;
            groupBox1.Visible = true;
            UkryKolory();
            PokazQuiz();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sciezka = "dane.txt";
            string szukaneNazwisko = textBox2.Text.Trim();
            if (File.Exists(sciezka) == false)
            {
                MessageBox.Show(szukaneNazwisko + ", rozwiązujesz test po raz pierwszy");
                return;
            }

            string[] linie = File.ReadAllLines(sciezka);
            bool czyZnaleziono = false;

            for (int i = 0; i < linie.Length; i++)
            {
                string aktualnaLinia = linie[i];

                string[] dane = aktualnaLinia.Split(' ');

                if (dane[0] == szukaneNazwisko)
                {
                    MessageBox.Show(dane[0] + " twój ostatni wynik z testu to " + dane[1] + " punkty");
                    czyZnaleziono = true;
                }
            }

            if (czyZnaleziono == false)
            {
                MessageBox.Show(szukaneNazwisko + ", rozwiązujesz test po raz pierwszy");
            }
        }

        private void koloryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PokazKolory();

            int red = hScrollBar1.Value;
            int green = hScrollBar2.Value;
            int blue = hScrollBar3.Value;

            textBox5.Text = hScrollBar1.Value.ToString();
            textBox6.Text = hScrollBar2.Value.ToString();
            textBox7.Text = hScrollBar3.Value.ToString();

            Color kolor = Color.FromArgb(red, green, blue);

            panel1.BackColor = kolor;

            textBox8.Text = "Red " + red + ", Green "+green+", Blue "+blue;
            UkryjQuiz();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            int red1 = hScrollBar1.Value;
            int green2 = hScrollBar2.Value;
            int blue2 = hScrollBar3.Value;

            textBox5.Text = hScrollBar1.Value.ToString();
            textBox6.Text = hScrollBar2.Value.ToString();
            textBox7.Text = hScrollBar3.Value.ToString();

            Color kolor = Color.FromArgb(red1, green2, blue2);

            panel1.BackColor = kolor;

            textBox8.Text = "Red " + red1 + ", Green " + green2 + ", Blue " + blue2;
            UkryjQuiz();
        }

        private void kołoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            UkryjQuiz();
            panel2.Visible = true;
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int punkty = 0;
            string nazwisko = textBox9.Text;

            if (textBox4.Text == "1") punkty++;

            if (radioButton2.Checked == true) punkty++;

            if (checkBox1.Checked && !checkBox2.Checked && checkBox3.Checked && !checkBox4.Checked && checkBox5.Checked)
            {
                punkty++;
            }

            if (comboBox1.Text == "29") punkty++;

            if (comboBox2.Text == "180°") punkty++;
            MessageBox.Show("Wynik quizu " + nazwisko + ": " + punkty + " pkt.");
            
            string sciezka = "dane.txt";

            if (!File.Exists(sciezka))
            {
                File.AppendAllText(sciezka, nazwisko + " " + punkty + Environment.NewLine);
            }
            else
            {
                string[] linie = File.ReadAllLines(sciezka);
                bool znaleziono = false;

                for (int i = 0; i < linie.Length; i++)
                {
                    string[] dane = linie[i].Split(' ');

                    if (dane[0] == nazwisko)
                    {
                        znaleziono = true;
                        int starePunkty = int.Parse(dane[1]);

                        if (punkty > starePunkty)
                        {
                            linie[i] = nazwisko + " " + punkty;
                        }
                    }
                }

                if (znaleziono)
                {
                    File.WriteAllLines(sciezka, linie);
                }
                else
                {
                    File.AppendAllText(sciezka, nazwisko + " " + punkty + Environment.NewLine);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }
    }
}
